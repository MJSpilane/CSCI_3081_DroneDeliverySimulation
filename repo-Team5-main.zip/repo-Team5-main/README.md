# repo-Team5
Team5 - Bek Allenson, Perrie Gryniewicz, Mathew Johnson, and Logan Watters

## All code can be found in the Project1 directory since we used the Project1 code as a basepoint for this project. 
## Updates testinglogs and unit/system test files can be found in the Project1/testing directory.
## All automated tests can be found in the testing folder in the src folder. 

When running the program from main with any of the testing files, the user will need to enter the file name in this format:
../testing/filename.csv

In practice, a user would move the csv file into the src folder directly, and would only have to type the filename.
