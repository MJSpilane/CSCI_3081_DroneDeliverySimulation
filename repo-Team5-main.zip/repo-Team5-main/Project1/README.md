# CSCI5801: Project2
## Team 5
Monday @ 6pm

To run: 
1. javac main.java
2. java main.java
3. Enter name of file - must be in the src directory or include path.

View results: 
* Winner(s) will be outputted to the command line.
* Audit file will appear in directory as auditFile.txt.
    * Audit file will not be appended to if not cleared out/renamed between elections.

Team5 - Bek Allenson (alle1423), Perrie Gryniewicz (gryni008), Matthew Johnson (joh18723), and Logan Watters (watte103)
