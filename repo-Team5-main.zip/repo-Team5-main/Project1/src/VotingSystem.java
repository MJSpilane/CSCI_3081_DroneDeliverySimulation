import java.io.*;
import java.util.*;

/**
 * VotingSystem abstract class that processes an election, allows for program
 * to be extended to other types of voting
 * @author Bek Allenson
 */
public abstract class VotingSystem {
    protected ArrayList<Candidate> candidates;
    protected int numberOfBallots;
    protected int numberOfCandidates;
    protected FileProcessor fileProcessor;
    protected Audit audit;

    /**
     * Default constructor
     */
    public VotingSystem() {
        super();
    }

    /**
     * Constructor
     * @param c list of candidates
     * @param numCandidates number of candidates in election
     * @param numBallots number of ballots in election
     * @param fp pointer to election file
     */
    public VotingSystem(ArrayList<Candidate> c, int numCandidates, int numBallots, File fp) {
        this.candidates = c;
        this.numberOfBallots = numBallots;
        this.numberOfCandidates = numCandidates;
        this.fileProcessor = new FileProcessor(fp, c);
        this.audit = new Audit();
    }

    /**
     * @return list of candidates in election
     */
    public ArrayList<Candidate> getCandidates() {
        return candidates;
    }

    /**
     * @return number of ballots in the election
     */
    public int getNumberOfBallots() {
        return numberOfBallots;
    }

    /**
     * @return number of candidates in the election
     */
    public int getNumberOfCandidates() {
        return numberOfCandidates;
    }

    /**
     * prints results of election, implemented by child classes
     */
    public abstract void printResults();

    /**
     * runs election, implemented by child classes
     * @return true if no errors, false otherwise
     */
    public abstract boolean runElection();
}