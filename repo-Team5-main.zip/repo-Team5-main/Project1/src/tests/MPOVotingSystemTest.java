import org.junit.*;
import java.io.*;
import java.util.ArrayList;
import static org.junit.Assert.*;

public class MPOVotingSystemTest {
    

    @Test
    public void testBreakTie() {
        ArrayList<Candidate> votes = new ArrayList<Candidate>();
        File fp = new File("./testing/MPOtest1.csv");
        OPLCandidate Fred = new OPLCandidate("Fred", "", 0);
        OPLCandidate Nate = new OPLCandidate("Nate", "", 0);
        votes.add(Fred);
        votes.add(Nate);
        int num1 = 0;
        int num2 = 0;
        HeaderProcessor hp = new HeaderProcessor(fp);
        MPOVotingSystem vs;
        try{
            vs = (MPOVotingSystem) hp.parseHeader();
        } catch (Exception e) {
            return;
        }
        for(int i = 0; i < 1000; i++) {
            int rand = vs.breakTie(2);
            if(rand == 0) {
                num1 +=1;
            }
            else if (rand == 1) {
                num2 +=1;
            }
        }
        double percentage1 = (double) num1 / 1000;
        double percentage2 = (double) num2 / 1000;
        assertTrue((percentage1 < 0.56) && (percentage1 > 0.44));
        assertTrue((percentage2 < 0.56) && (percentage2 > 0.44));
    }
    
    @Test 
    public void testBreakTieMultiple() {
        ArrayList<Candidate> votes = new ArrayList<Candidate>();
        File fp = new File("testing/MPOtest1.csv");
        OPLCandidate Fred = new OPLCandidate("Fred", "", 0);
        OPLCandidate Nate = new OPLCandidate("Nate", "", 0);
        OPLCandidate Sam = new OPLCandidate("Sam", "", 0);
        votes.add(Fred);
        votes.add(Nate);
        votes.add(Sam);
        int num1 = 0;
        int num2 = 0;
        int num3 = 0;
        HeaderProcessor hp = new HeaderProcessor(fp);
        MPOVotingSystem vs;
        try {
            vs = (MPOVotingSystem) hp.parseHeader();
        } catch (Exception e) {
            return;
        }
        for(int i = 0; i < 1000; i++) {
            int rand = vs.breakTie(3);
            if(rand == 0) {
                num1 +=1;
            }
            else if (rand == 1) {
                num2 +=1;
            }
            else if (rand == 2) {
                num3 +=1;
            }
        }
        double percentage1 = (double) num1 / 1000;
        double percentage2 = (double) num2 / 1000;
        double percentage3 = (double) num3 / 1000;
        assertTrue((percentage1 > 0.27) && (percentage1 < 0.39));
        assertTrue((percentage2 > 0.27) && (percentage2 < 0.39));
        assertTrue((percentage3 > 0.27) && (percentage3 < 0.39));
    }
}