import java.awt.Desktop;
import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;
public class tc_016 {
    /**
     * Tests giveBallots() ability to not give a ballot to a candidate that is not in the running.
     */
    public static void main(String args[]) throws FileNotFoundException {

        IRCandidate testingCandidate = new IRCandidate("Logan Watters", "D", 0);
        testingCandidate.removeCandidate();
        ArrayList<Candidate> testingBallot = new ArrayList<Candidate>();
        testingBallot.add(testingCandidate);
        testingCandidate.giveBallot(new IRBallot(testingBallot));
        System.out.println(testingCandidate.getBallotCount());
    }
}
