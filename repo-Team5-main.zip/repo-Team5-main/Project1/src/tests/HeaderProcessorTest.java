import org.junit.*;
import static org.junit.Assert.*;
import java.io.File;
import java.util.ArrayList;

public class HeaderProcessorTest {
    @Test
    public void testParseHeaderIR() throws Throwable {
        File fp = new File("./testing/testHeaderIR.csv");
        HeaderProcessor hp = new HeaderProcessor(fp);

        VotingSystem vs = hp.parseHeader();
        assertEquals("IR", hp.getVotingSystem());
        assertEquals(4, hp.getNumCandidates());

        ArrayList<Candidate> candidates = hp.getCandidates();
        // candidate Rosen (D)
        Candidate rosen = candidates.get(0);
        assertEquals("osen", rosen.getName());
        assertEquals("D", rosen.getParty());
        assertEquals(0, rosen.getBallotIndex());
        // candidate Kleinberg (R)
        Candidate kleinberg = candidates.get(1);
        assertEquals("Kleinberg", kleinberg.getName());
        assertEquals("R", kleinberg.getParty());
        assertEquals(1, kleinberg.getBallotIndex());
        // candidate Chou (I)
        Candidate chou = candidates.get(2);
        assertEquals("Chou", chou.getName());
        assertEquals("I", chou.getParty());
        assertEquals(2, chou.getBallotIndex());
        // candidate Royce (L)
        Candidate royce = candidates.get(3);
        assertEquals("Royce", royce.getName());
        assertEquals("L", royce.getParty());
        assertEquals(3, royce.getBallotIndex());

        assertEquals(6, hp.getNumBallots());

        assertEquals(vs.getCandidates(), hp.getCandidates());
    }
}
