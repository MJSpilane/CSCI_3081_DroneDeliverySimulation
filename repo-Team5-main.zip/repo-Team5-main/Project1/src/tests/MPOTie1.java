import java.lang.Math;
import java.io.File;
import java.util.ArrayList;
public class MPOTie1 {
    public static void main(String[] args) throws Throwable {
        ArrayList<Candidate> votes;
        File fp = new File("./testing/twowaytieforoneseat.csv");

        int candidate1 = 0;
        int candidate2 = 0;
        String candidate1name = "Pike";
        String candidate2name = "Foster";
        HeaderProcessor hp = new HeaderProcessor(fp);
        MPOVotingSystem vs;
        try{
            vs = (MPOVotingSystem) hp.parseHeader();
            votes = hp.getCandidates();
        }catch (Exception e) {
            return;
        }
        for(int i = 0; i < 1000; i++) {
            int winner = vs.breakTie(2);
            if(winner == 0){
                candidate1 +=1;
            }
            else if(winner == 1){
                candidate2 +=1;
            }
        }
        double percentage1 = (double) candidate1 / 1000;
        double percentage2 = (double) candidate2 / 1000;
        System.out.println(java.lang.Math.abs(percentage1-percentage2) <= 0.05);
        candidate1 = 0; 
        candidate2 = 0; 
        for(int i = 0; i<1000; i++) {
            vs.runElection();
            // System.out.println("I have made it out");
            // System.out.println(i);
            String[] winner = vs.getWinners();
            //System.out.println(winner.length);
            for(int j = winner.length -1; j>=0; j--) {
                if(winner[j].equals(candidate1name)) {
                    candidate1++;
                }
                else if (winner[j].equals(candidate2name)) {
                    candidate2++;
                }
            }
        }
        percentage1 = (double) candidate1 / 1000;
        percentage2 = (double) candidate2 / 1000;
        System.out.println(candidate1);
        System.out.println(candidate2);
        System.out.println(java.lang.Math.abs(percentage1-percentage2) <= 0.05);
    }
}
