import org.junit.*;
import static org.junit.Assert.*;
import java.io.File;
import java.util.ArrayList;

public class MPOParsingTest {
    @Test
    public void testParseHeaderMPO() throws Throwable {
        File fp = new File("./testing/testHeaderMPO.csv");
        HeaderProcessor hp = new HeaderProcessor(fp);

        VotingSystem vs = hp.parseHeader();
        assertEquals("MPO", hp.getVotingSystem());
        assertEquals(2, hp.getNumCandidates());

        ArrayList<Candidate> candidates = hp.getCandidates();
        // candidate Pike (D)
        Candidate pike = candidates.get(0);
        assertEquals("Pike", pike.getName());
        assertEquals("D", pike.getParty());
        assertEquals(0, pike.getBallotIndex());
        // candidate Deutsch (R)
        Candidate deutsch = candidates.get(1);
        assertEquals("Deutsch", deutsch.getName());
        assertEquals("R", deutsch.getParty());
        assertEquals(1, deutsch.getBallotIndex());

        assertEquals(6, hp.getNumBallots());

        assertEquals(vs.getCandidates(), hp.getCandidates());
    }
    @Test
    public void testParseBallotsMPO() throws Throwable {
        File fp = new File("testing/testBallotsMPO.csv");
        HeaderProcessor hp = new HeaderProcessor(fp);

        VotingSystem vs = hp.parseHeader();

        ArrayList<Candidate> candidates = hp.getCandidates();
        // pike should have 2 votes, Deutsch should have 0
        MPOCandidate pike = (MPOCandidate) candidates.get(0);
        assertEquals(2, pike.getBallotCount());

        MPOCandidate deutsch = (MPOCandidate) candidates.get(1);
        assertEquals(0, deutsch.getBallotCount());
    }

}
