import java.awt.Desktop;
import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;
public class tc_015 {
    /**
    * tests the ability of FileProcessor to return an empty list if the election contains no ballots. 
    */
    public static void main(String args[]) throws FileNotFoundException {

        FileProcessor fp = new FileProcessor(new File("./testing/emptyelection.csv"), new ArrayList<Candidate>());
        System.out.println(fp.getBallots());
    }
}
