import java.awt.Desktop;
import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;
public class tc_019 {
    /**
     * Tests giveBallots() ability to give a ballot to a candidate (the IRBallot constructor calls this method). 
     */
    public static void main(String args[]) throws FileNotFoundException {

        IRCandidate candidate1 = new IRCandidate("Ron Johnson", "G", 1);
        IRCandidate candidate2 = new IRCandidate("Jon Rohnson", "R", 4);
        IRCandidate candidate3 = new IRCandidate("Candice Tyler", "D", 3);
        IRCandidate candidate4 = new IRCandidate("Audrey Owens", "I", 2);
        System.out.println(candidate1.getBallotCount());
        ArrayList<Candidate> testingBallot = new ArrayList<Candidate>();
        testingBallot.add(candidate1);
        testingBallot.add(candidate2);
        testingBallot.add(candidate3);
        testingBallot.add(candidate4);
        IRBallot testBallot = new IRBallot(testingBallot);
        System.out.println(candidate1.getBallotCount());
    }
}
