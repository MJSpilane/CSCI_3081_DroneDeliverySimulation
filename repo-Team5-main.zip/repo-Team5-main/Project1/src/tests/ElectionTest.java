import java.io.File;
import org.junit.*;
import static org.junit.Assert.*;


public class ElectionTest {
    
    @Test 
    public void testConstructor() throws Throwable{
        File fp = new File("./testing/ElectionTester.csv");
        Election e = new Election(fp);

        assertEquals(fp, e.getFp());
        assertNotEquals(null, e.getHeaderProcessor());
        assertNotEquals(null, e.getVotingSystem());
    }
}
