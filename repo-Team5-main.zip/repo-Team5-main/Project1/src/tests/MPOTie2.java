import java.lang.Math;
import java.util.ArrayList;
import java.io.File;
public class MPOTie2 {
    public static void main(String[] args) {
        ArrayList<Candidate> votes;
        File fp = new File("./testing/twowaytieforsecondseat.csv");

        int candidate1 = 0;
        int candidate2 = 0;
        String candidate1name = "Foster";
        String candidate2name = "Borg";
        HeaderProcessor hp = new HeaderProcessor(fp);
        MPOVotingSystem votingSystem;
        try{
            votingSystem = (MPOVotingSystem) hp.parseHeader();
            votes = hp.getCandidates();
        }catch (Exception e) {
            
            return;
        }
        for(int i = 0; i < 1000; i++) {
            int winner = votingSystem.breakTie(2);
            if(winner == 0){
                candidate1 +=1;
            }
            else if(winner == 1){
                candidate2 +=1;
            }
        }
        double percentage1 = (double) candidate1 / 1000;
        double percentage2 = (double) candidate2 / 1000;
        System.out.println(java.lang.Math.abs(percentage1-percentage2) <= 0.05);
        candidate1 = 0; 
        candidate2 = 0; 
        for(int i = 0; i<1000; i++) {
            votingSystem.runElection();
            String[] winner = votingSystem.getWinners();
            for(int j = winner.length -1; j>=0; j--) {
                if(winner[j].equals(candidate1name)) {
                    candidate1++;
                }
                else if (winner[j].equals(candidate2name)) {
                    candidate2++;
                }
            }
        }
        percentage1 = (double) candidate1 / 1000;
        percentage2 = (double) candidate2 / 1000;
        System.out.println(java.lang.Math.abs(percentage1-percentage2) <= 0.05);
    }
}
