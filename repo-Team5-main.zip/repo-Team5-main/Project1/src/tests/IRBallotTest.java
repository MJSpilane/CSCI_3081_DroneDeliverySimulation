import org.junit.*;


import java.util.ArrayList;

import static org.junit.Assert.*;

public class IRBallotTest {
    @Test
    public void testConstructor() {
        ArrayList<Candidate> votes = new ArrayList<Candidate>();
       Candidate Reginald = new IRCandidate("Reginald", "R", 0);
       Candidate Jerrifer = new IRCandidate("Jerrifer", "R", 0);
       Candidate JohnnyBoy = new IRCandidate("JohnnyBoy", "D", 0);
       Candidate Hannah = new IRCandidate("Hannah", "D", 0);
       votes.add(Reginald); //first choice
       votes.add(Hannah); //second choice, etc.
       votes.add(Jerrifer);
       votes.add(JohnnyBoy);

       ArrayList<Candidate> twoVotes = new ArrayList<Candidate>();
       twoVotes.add(Hannah);
       twoVotes.add(JohnnyBoy);

       ArrayList<Candidate> oneVote = new ArrayList<Candidate>();
       oneVote.add(Reginald);
       IRBallot b = new IRBallot(votes);
       assertTrue(b.getValid());
       assertEquals(0, b.getRank());
       assertEquals(votes.get(0).getName(), b.getCandidate().getName());
       assertEquals(votes.get(1).getName(), b.getVotes().get(1).getName());
       assertEquals(votes.get(2).getName(), b.getVotes().get(2).getName());
       assertEquals(votes.get(3).getName(), b.getVotes().get(3).getName());

       IRBallot twoB = new IRBallot(twoVotes);
       assertTrue(twoB.getValid());
       assertEquals(0, twoB.getRank());
       assertEquals(twoVotes.get(0).getName(), twoB.getVotes().get(0).getName());
       assertEquals(twoVotes.get(1).getName(), twoB.getVotes().get(1).getName());

       IRBallot oneB = new IRBallot(oneVote);
       assertTrue(oneB.getValid());
       assertEquals(0, oneB.getRank());
       assertEquals(oneVote.get(0).getName(), oneB.getVotes().get(0).getName());
   }


   @Test
   public void testGetCandidate() {
        ArrayList<Candidate> votes = new ArrayList<Candidate>();
       Candidate Reginald = new IRCandidate("Reginald", "R", 0);
       Candidate Jerrifer = new IRCandidate("Jerrifer", "R", 0);
       Candidate JohnnyBoy = new IRCandidate("JohnnyBoy", "D", 0);
       Candidate Hannah = new IRCandidate("Hannah", "D", 0);
       votes.add(Reginald); //first choice
       votes.add(Hannah); //second choice, etc.
       votes.add(Jerrifer);
       votes.add(JohnnyBoy);
       IRBallot ballot = new IRBallot(votes);

       assertEquals(votes.get(0).getName(), ballot.getCandidate().getName());
       ballot.setRank(1);
       assertEquals(votes.get(1).getName(), ballot.getCandidate().getName());
       ballot.setRank(2);
       assertEquals(votes.get(2).getName(), ballot.getCandidate().getName());
       ballot.setRank(3);
       assertEquals(votes.get(3).getName(), ballot.getCandidate().getName());

       IRBallot invalidBallot = new IRBallot(votes);
       invalidBallot.setValid(false);
       assertEquals(null, invalidBallot.getCandidate());
   }

   @Test
   public void testGetNextCandidate() {
       ArrayList<Candidate> votes = new ArrayList<Candidate>();
       Candidate Reginald = new IRCandidate("Reginald", "R", 0);
       Candidate Jerrifer = new IRCandidate("Jerrifer", "R", 0);
       Candidate JohnnyBoy = new IRCandidate("JohnnyBoy", "D", 0);
       Candidate Hannah = new IRCandidate("Hannah", "D", 0);
       votes.add(Reginald); //first choice
       votes.add(Hannah); //second choice, etc.
       votes.add(Jerrifer);
       votes.add(JohnnyBoy);
       ArrayList<Candidate> twoVotes = new ArrayList<Candidate>();
       twoVotes.add(Hannah);
       twoVotes.add(JohnnyBoy);

       ArrayList<Candidate> oneVote = new ArrayList<Candidate>();
       oneVote.add(Reginald);
       IRBallot baseBallot = new IRBallot(votes);
       IRBallot lastIndexBallot = new IRBallot(oneVote);

       ArrayList<Candidate> invalidCandidateInMiddle = new ArrayList<Candidate>();
       IRCandidate Jeff = new IRCandidate("Jeff", "", 0);
       IRCandidate Leo = new IRCandidate("Leo", "", 0);
       Leo.setInRunning(false);
       Candidate Henry = new IRCandidate("Henry", "", 0);
       invalidCandidateInMiddle.add(Jeff);
       invalidCandidateInMiddle.add(Leo);
       invalidCandidateInMiddle.add(Henry);
       IRBallot middleInvalidBallot = new IRBallot(invalidCandidateInMiddle);

       IRCandidate Kate = new IRCandidate("Kate", "", 0);
       IRCandidate Jenny = new IRCandidate("Jenny", "", 0);
       Jenny.setInRunning(false);
       IRCandidate Regina = new IRCandidate("Regina", "", 0);
       Regina.setInRunning(false);
       ArrayList<Candidate> restOfCandidatesInvalid = new ArrayList<Candidate>();
       restOfCandidatesInvalid.add(Kate);
       restOfCandidatesInvalid.add(Jenny);
       restOfCandidatesInvalid.add(Regina);
       IRBallot restInvalidBallot = new IRBallot(restOfCandidatesInvalid);

    //base case
       assertEquals(votes.get(0).getName(), baseBallot.getCandidate().getName());
       assertTrue(baseBallot.getNextCandidate());
       assertEquals(votes.get(1).getName(), baseBallot.getCandidate().getName());

    //last index ballot case
       assertEquals(oneVote.get(0).getName(), lastIndexBallot.getCandidate().getName());
       assertFalse(lastIndexBallot.getNextCandidate());
       assertFalse(lastIndexBallot.getValid());

    //next Candidate is invalid case (ensure it skips the invalid Candidate in the middle)
       assertEquals(invalidCandidateInMiddle.get(0).getName(), middleInvalidBallot.getCandidate().getName());
       assertTrue(middleInvalidBallot.getNextCandidate());
       assertEquals(invalidCandidateInMiddle.get(2).getName(), middleInvalidBallot.getCandidate().getName());

    //rest of Candidates are all invalid
       assertEquals(restOfCandidatesInvalid.get(0).getName(), restInvalidBallot.getCandidate().getName());
       assertFalse(restInvalidBallot.getNextCandidate());
       assertFalse(restInvalidBallot.getValid());
   }
}
