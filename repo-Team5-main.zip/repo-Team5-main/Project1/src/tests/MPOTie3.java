import java.lang.Math;
import java.io.File;
import java.util.ArrayList;
public class MPOTie3 {

    public static void main(String[] args){
        ArrayList<Candidate> votes;
        File fp = new File("./testing/threewaytiefortwoseats.csv");

        int candidate1 = 0;
        int candidate2 = 0;
        int candidate3 = 0; 
        String candidate1name = "Pike";
        String candidate2name = "Foster";
        String candidate3name = "Borg";
        HeaderProcessor hp = new HeaderProcessor(fp);
        MPOVotingSystem votingSystem;
        try{
            votingSystem = (MPOVotingSystem) hp.parseHeader();
            votes = hp.getCandidates();
        }catch (Exception e) {
            System.out.println(e.getMessage());
            System.out.println("there was an error");
            return;
        }
        for(int i = 0; i < 1000; i++) { // testing to make sure that it is doing it roughly 1/3 of the time
            int winner = votingSystem.breakTie(3);
            if(winner == 0){
                candidate1++;
            }
            else if(winner == 1){
                candidate2++;
            }
            else if(winner == 2) {
                candidate3++;
            }
        }
        double percentage1 = (double) candidate1 / 1000;
        double percentage2 = (double) candidate2 / 1000;
        double percentage3 = (double) candidate3 / 1000;
        System.out.println(percentage1);
        System.out.println(percentage2);
        System.out.println(percentage3);
        System.out.println(java.lang.Math.abs(percentage1-percentage2) <= 0.05 && java.lang.Math.abs(percentage1-percentage3) <= 0.05 && java.lang.Math.abs(percentage3 - percentage2) <= 0.05);
        candidate1 = 0; 
        candidate2 = 0; 
        candidate3 = 0; 
        for(int i = 0; i<1000; i++) {
            votingSystem.runElection();
            String[] winner = votingSystem.getWinners();
            for(int j = winner.length -1; j>=0; j--) {
                if(winner[j].equals(candidate1name)) {
                    candidate1++;
                }
                else if (winner[j].equals(candidate2name)){
                    candidate2++;
                }
                else if (winner[j].equals(candidate3name)){
                    candidate3++;
                }
            }
        }
        percentage1 = (double) candidate1 / 1000;
        percentage2 = (double) candidate2 / 1000;
        percentage3 = (double) candidate3 / 1000;
        System.out.println(percentage1);
        System.out.println(percentage2);
        System.out.println(percentage3);
        System.out.println(java.lang.Math.abs(percentage1-percentage2) <= 0.1 && java.lang.Math.abs(percentage1-percentage3) <= 0.1 && java.lang.Math.abs(percentage3 - percentage2) <= 0.1);
    }
}

