import java.awt.Desktop;
import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;
public class tc_017 {
    /**
     * Tests the ability of FileProcessor to return an empty list if no election type is specified. 
     */
    public static void main(String args[]) throws FileNotFoundException {

        FileProcessor fp = new FileProcessor(new File("./testing/nooplorir.csv"), new ArrayList<Candidate>());
        System.out.println(fp.getBallots());

    }
}
