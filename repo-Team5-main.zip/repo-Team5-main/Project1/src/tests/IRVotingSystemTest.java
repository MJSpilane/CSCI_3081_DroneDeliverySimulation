import org.junit.*;

import java.io.File;
import java.util.ArrayList;

import static org.junit.Assert.*;


public class IRVotingSystemTest {

    @Test
    public void testCheckMajorityTrue() {

        ArrayList<Candidate> votes = new ArrayList<Candidate>();
        File fp = new File("./testing/ElectionTest.csv");
        IRCandidate Tim = new IRCandidate("Tim", "", 0);
        IRCandidate Randy = new IRCandidate("Randy", "", 0);
        IRCandidate Tom = new IRCandidate("Tom", "", 0);
        votes.add(Tim);
        votes.add(Randy);
        votes.add(Tom);
        IRBallot bal1 = new IRBallot(votes);
        IRBallot bal2 = new IRBallot(votes);
        IRBallot bal3 = new IRBallot(votes);
        IRBallot bal4 = new IRBallot(votes);
        IRBallot bal5 = new IRBallot(votes);
        //Candidate has majority
        Tim.giveBallot(bal1);
        Tim.giveBallot(bal2);
        Tim.giveBallot(bal3);
        Randy.giveBallot(bal4);
        Tom.giveBallot(bal5);
        HeaderProcessor hp = new HeaderProcessor(fp);
        IRVotingSystem vs;
        try{
        vs = (IRVotingSystem) hp.parseHeader();
        }catch (Exception e) {
            return;
        }
        assertTrue(vs.checkMajority());
    }

    @Test
    public void testCheckMajorityFalse() {
        ArrayList<Candidate> votes = new ArrayList<Candidate>();
        File fp = new File("testing/ElectionTest.csv");
        IRCandidate Tim = new IRCandidate("Tim", "", 0);
        IRCandidate Randy = new IRCandidate("Randy", "", 0);
        IRCandidate Tom = new IRCandidate("Tom", "", 0);
        votes.add(Tim);
        votes.add(Randy);
        votes.add(Tom);
        IRBallot bal1 = new IRBallot(votes);
        IRBallot bal2 = new IRBallot(votes);
        IRBallot bal3 = new IRBallot(votes);
        IRBallot bal4 = new IRBallot(votes);
        IRBallot bal5 = new IRBallot(votes);
        //No candidate has majority
        Tim.giveBallot(bal1);
        Tim.giveBallot(bal2);
        Tom.giveBallot(bal3);
        Tom.giveBallot(bal4);
        Randy.giveBallot(bal5);
        HeaderProcessor hp = new HeaderProcessor(fp);
        IRVotingSystem vs;
        try{
        vs = (IRVotingSystem) hp.parseHeader();
        }catch (Exception e) {
            return;
        }
        assertFalse(vs.checkMajority());
    }

    @Test
    public void testBreakTie() {
        ArrayList<Candidate> votes = new ArrayList<Candidate>();
        File fp = new File("testing/ElectionTest.csv");
        IRCandidate Tim = new IRCandidate("Tim", "", 0);
        IRCandidate Randy = new IRCandidate("Randy", "", 0);
        IRCandidate Tom = new IRCandidate("Tom", "", 0);
        votes.add(Tim);
        votes.add(Randy);
        votes.add(Tom);
        int num1 = 0;
        int num2 = 0;
        HeaderProcessor hp = new HeaderProcessor(fp);
        IRVotingSystem vs;
        try{
        vs = (IRVotingSystem) hp.parseHeader();
        }catch (Exception e) {
            return;
        }
        for(int i = 0; i < 1000; i++) {
            int rand = vs.breakTie(2);
            if(rand == 0){
                num1 +=1;
            }
            else if(rand == 1){
                num2 +=1;
            }
        }
        double percentage1 = (double) num1 / 1000;
        double percentage2 = (double) num2 / 1000;
        assertTrue(percentage1 < 0.56); // only 5% deviation from 50%
        assertTrue(percentage1 > 0.44);
        assertTrue(percentage2 < 0.56);
        assertTrue(percentage2 > 0.44);
    }

    @Test
    public void testBreakTieMultiple() {
        ArrayList<Candidate> votes = new ArrayList<Candidate>();
        File fp = new File("testing/BallotRedistributeTester.csv");
        IRCandidate Tim = new IRCandidate("Tim", "", 0);
        IRCandidate Randy = new IRCandidate("Randy", "", 0);
        IRCandidate Tom = new IRCandidate("Tom", "", 0);
        votes.add(Tim);
        votes.add(Randy);
        votes.add(Tom);
        int num1 = 0;
        int num2 = 0;
        int num3 = 0;
        HeaderProcessor hp = new HeaderProcessor(fp);
        IRVotingSystem vs;
        try{
        vs = (IRVotingSystem) hp.parseHeader();
        }catch (Exception e) {
            return;
        }
        for(int i = 0; i < 1000; i++) {
            int rand = vs.breakTie(3);
            if(rand == 0){
                num1 +=1;
            }
            else if (rand==1) {
                num2 +=1;
            }
            else if (rand==2) {
                num3 +=1;
            }
        }
        double percentage1 = (double) num1 / 1000;
        double percentage2 = (double) num2 /1000;
        double percentage3 = (double) num3/ 1000;
        assertTrue((percentage1 > 0.27) && (percentage1 < 0.39)); // only 5% deviation from 33%
        assertTrue((percentage2 > 0.27) && (percentage2 < 0.39));
        assertTrue((percentage3 > 0.27) && (percentage3 < 0.39));
    }
}
